/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Business.Enterprise.Enterprise;
import Business.Network.Network;
import Business.Role.ApplicantRole;
import Business.Role.EnterpriseAdminRole;
import Business.Role.HRRole;
import Business.Role.Role;
import Business.Role.SystemAdminRole;
import Business.UserAccount.UserAccount;
import java.util.ArrayList;
import java.util.HashSet;
import Business.Organization.Organization;
import Business.Role.AccountantRole;
import Business.Role.ContractorManagerRole;
import Business.Role.TFAManagerRole;
import Business.Role.TrainingOfficerRole;
/**
 *
 * @author Vrushali
 */
public class EcoSystem extends Organization{
      public static EcoSystem business;
    private ArrayList<Network> networkList;
    
    
    
    public static EcoSystem getInstance() {
        if (business == null) {
            business = new EcoSystem();
        }
        return business;
    }

    public EcoSystem() {
        super(null);
        networkList = new ArrayList<>();
        //applicantDirectory = new ApplicantDirectory();
        
        
    }

//    public ApplicantDirectory getApplicantDirectory() {
//        return applicantDirectory;
//    }
//
//    public void setApplicantDirectory(ApplicantDirectory applicantDirectory) {
//        this.applicantDirectory = applicantDirectory;
//    }

    

    

    public static EcoSystem getBusiness() {
        return business;
    }
    
    public static void setInstance(EcoSystem business) {
        business=business;
    }

    public ArrayList<Network> getNetworkList() {
        return networkList;
    }
       
     public Network createAndAddNetwork() {
        Network network = new Network();
        networkList.add(network);
        return network;
    }
     
    @Override
    public HashSet<Role> getSupportedRole() {
        roles.add(new SystemAdminRole());
        roles.add(new ContractorManagerRole());
        roles.add(new EnterpriseAdminRole());
        roles.add(new HRRole());
        roles.add(new TFAManagerRole());
        roles.add(new TrainingOfficerRole());
        roles.add(new ApplicantRole());
        roles.add(new AccountantRole());
        return roles;
    }
    
    public static boolean checkIfUsernameIsUnique(String username) {

      //  if (!this.getUserAccountDirectory().checkIfUsernameIsUnique(username)) {
             for (Network network : business.getNetworkList()) {
                 
                for (Enterprise enterprise : network.getEnterpriseDirectory().getEnterpriseList()) {
                    for (UserAccount ua : enterprise.getUserAccountDirectory().getUserAccountList()) {
                        if(ua.getUsername().equals(username)){
                            return false;
                        }
                    }
                    
                        for (Organization organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
                            for (UserAccount ua : organization.getUserAccountDirectory().getUserAccountList()) {
                                 if(ua.getUsername().equals(username)){
                            return false;
                        }
                    }
                            }
                        }
                    }
            
      //  }

       

        return true;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Applicant.ApplicantDirectory;
import Business.Role.ContractorManagerRole;
import Business.Role.Role;
import Business.InternDirectory.InternDirectory;
import Business.Role.HRRole;
import Business.Role.SupervisorRole;
import java.util.HashSet;

/**
 *
 * @author Vrushali
 */
public class ContractorOrganization extends Organization{
    public InternDirectory internDirectory;
    public ContractorOrganization() {
        super(Organization.Type.ContractorOrg.getValue());
        this.internDirectory= new InternDirectory();
    }

    @Override
    public HashSet<Role> getSupportedRole() {
        roles.add(new ContractorManagerRole());
        //roles.add(new SupervisorRole());
        return roles;
    }

    public InternDirectory getInternDirectory() {
        return internDirectory;
    }

    public void setInternDirectory(InternDirectory internDirectory) {
        this.internDirectory = internDirectory;
    }

    


  
    
}

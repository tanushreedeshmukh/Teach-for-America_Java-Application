/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Applicant.Applicant;
import Business.Jobs.Job;
import Business.Role.AccountantRole;
import Business.Role.ContractorManagerRole;
import Business.Role.HRRole;
import Business.Role.Role;
import Business.Role.SupervisorRole;
import Business.Role.TrainingOfficerRole;
import java.util.HashSet;

/**
 *
 * @author Vrushali
 */
public class TFAOrganization extends Organization{
     Applicant a;
    Job j;

    public TFAOrganization() {
        super(Type.TFAOrg.getValue());
        a = new Applicant();
        j = new Job();
    }

    public Applicant getA() {
        return a;
    }
    
    public void setA(Applicant a) {
        this.a = a;
    }
    
    @Override
    public HashSet<Role> getSupportedRole() {
       // roles.add(new CompanyManagerRole());
        roles.add(new TrainingOfficerRole());
        roles.add(new HRRole());
          roles.add(new SupervisorRole());
        roles.add(new ContractorManagerRole());
         roles.add(new AccountantRole());
        return roles;
        
    }    
    
}

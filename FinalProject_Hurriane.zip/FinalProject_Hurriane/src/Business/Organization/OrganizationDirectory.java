/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;
import Business.Organization.Organization.Type;
import java.util.ArrayList;

/**
 *
 * @author Vrushali
 */
public class OrganizationDirectory {
    private ArrayList<Organization> organizationList;
    //public JobDirectory jobDirectory;
    
    
    

    public OrganizationDirectory() {
        organizationList = new ArrayList<>();
        //jobDirectory = new JobDirectory();
    }

    public ArrayList<Organization> getOrganizationList() {
        return organizationList;
    }
    
    public Organization createOrganization(Type type){
        Organization organization = null;
        if (type.getValue().equals(Type.TFAOrg.getValue())){
            organization = new TFAOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.ContractorOrg.getValue())){
            organization = new ContractorOrganization();
            organizationList.add(organization);
        }
       
        return organization;
    }
    
}

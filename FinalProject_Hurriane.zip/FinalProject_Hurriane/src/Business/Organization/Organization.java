package Business.Organization;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import Business.Applicant.ApplicantDirectory;
import Business.Application.ApplicationDirectory;
import Business.Employee.EmployeeDirectory;
import Business.Role.Role;
import Business.UserAccount.UserAccountDirectory;
import Business.ApplicationWorkQueue.WorkQueue;
import Business.Budget.BudgetDirectory;
import Business.Jobs.JobDirectory;

import java.util.ArrayList;
import java.util.HashSet;

/**
 *
 * author @Vrushali
 */
public abstract class Organization {

    private String name;
    private WorkQueue workQueue;
    private EmployeeDirectory employeeDirectory;
    //private ApplicantDirectory applicantDirectory;
    private UserAccountDirectory userAccountDirectory;
    private ApplicantDirectory applicantDirectory;
    private ApplicationDirectory applicationDirectory;
       private BudgetDirectory budgetDirectory;
    private int organizationID;
    private JobDirectory jobDirectory;
    private static int counter=0;
    public HashSet<Role> roles;
    
    public enum Type{
        TFAOrg("TFA Organization"),
        ContractorOrg("Contractor Organization");
        private String value;
        private Type(String value) {
            this.value = value;
        }
        public String getValue() {
            return value;
        }
    }

    public Organization(String name) {
        this.name = name;
        workQueue = new WorkQueue();
        employeeDirectory = new EmployeeDirectory();
        userAccountDirectory = new UserAccountDirectory();
        organizationID = counter;
        roles = new HashSet<>();
        ++counter;
        jobDirectory= new JobDirectory();
        applicantDirectory = new ApplicantDirectory();
        applicationDirectory = new ApplicationDirectory();
          }

    public abstract HashSet<Role> getSupportedRole();

   
    
    
    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    public int getOrganizationID() {
        return organizationID;
    }

    public EmployeeDirectory getEmployeeDirectory() {
        return employeeDirectory;
    }

    public JobDirectory getJobDirectory() {
        return jobDirectory;
    }

    public void setJobDirectory(JobDirectory jobDirectory) {
        this.jobDirectory = jobDirectory;
    }
    
    public String getName() {
        return name;
    }

    public WorkQueue getWorkQueue() {
        return workQueue;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setWorkQueue(WorkQueue workQueue) {
        this.workQueue = workQueue;
    }

    public ApplicantDirectory getApplicantDirectory() {
        return applicantDirectory;
    }

    public void setApplicantDirectory(ApplicantDirectory applicantDirectory) {
        this.applicantDirectory = applicantDirectory;
    }

    public ApplicationDirectory getApplicationDirectory() {
        return applicationDirectory;
    }

    public void setApplicationDirectory(ApplicationDirectory applicationDirectory) {
        this.applicationDirectory = applicationDirectory;
    }

    public BudgetDirectory getBudgetDirectory() {
        return budgetDirectory;
    }

    public void setBudgetDirectory(BudgetDirectory budgetDirectory) {
        this.budgetDirectory = budgetDirectory;
    }
    
    @Override
    public String toString() {
        return name;
    }
}
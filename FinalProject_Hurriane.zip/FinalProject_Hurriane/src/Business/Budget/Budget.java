/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Budget;

/**
 *
 * @author Aishwarya
 */
public class Budget {
   private String resourcesbudget;
private String sponsorshipcost;
private String labourcost;
private String totalexpense;
private String month;
private String year;

    public String getResourcesbudget() {
        return resourcesbudget;
    }

    public void setResourcesbudget(String resourcesbudget) {
        this.resourcesbudget = resourcesbudget;
    }

    public String getSponsorshipcost() {
        return sponsorshipcost;
    }

    public void setSponsorshipcost(String sponsorshipcost) {
        this.sponsorshipcost = sponsorshipcost;
    }

    public String getLabourcost() {
        return labourcost;
    }

    public void setLabourcost(String labourcost) {
        this.labourcost = labourcost;
    }

    public String getTotalexpense() {
        return totalexpense;
    }

    public void setTotalexpense(String totalexpense) {
        this.totalexpense = totalexpense;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }


}

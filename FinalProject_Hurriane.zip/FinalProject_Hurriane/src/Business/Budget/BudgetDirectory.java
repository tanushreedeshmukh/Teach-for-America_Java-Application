/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Budget;

import java.util.ArrayList;

/**
 *
 * @author Aishwarya
 */
public class BudgetDirectory {
    private ArrayList<Budget> budgetlist; 
    
    public BudgetDirectory(){
    this.budgetlist=new ArrayList<>();
}

    public ArrayList<Budget> getBudgetlist() {
        return budgetlist;
    }

    public void setBudgetlist(ArrayList<Budget> budgetlist) {
        this.budgetlist = budgetlist;
    }
    
    public Budget addBudget(String labourcost, String resourcescost, String sponsorshipcost, String month, String year) {
       Budget budget1=new Budget();
       budget1.setLabourcost(labourcost);
       budget1.setResourcesbudget(resourcescost);
       budget1.setSponsorshipcost(sponsorshipcost);
       budget1.setMonth(month);
       budget1.setYear(year);
       return budget1;
   }
    
    
          public Budget addRecord(){
        Budget bud= new Budget();
        budgetlist.add(bud);
        return bud;
    }
    
}

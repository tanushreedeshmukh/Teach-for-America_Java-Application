/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.ApplicationWorkQueue;

import Business.Applicant.Applicant;
import Business.ContractorPersonDirectory.Contractor;
import Business.InternDirectory.Intern;
import Business.Jobs.Job;

/**
 *
 * @author Tanushree
 */
public class ApplicantWorkRequest extends WorkRequest {

    public Job job;
    public Applicant applicant;
    private int applicationID;
    private String status;
    private Intern intern;
    private Contractor contractor;
    
    private Boolean flag;
    private String sendername;
    
    
    
    public ApplicantWorkRequest() {
        
        this.job = new Job();
        this.applicant = new Applicant();
        this.intern=intern;
        this.contractor=contractor;
       
    }

    public String getSendername() {
        return sendername;
    }

    public void setSendername(String sendername) {
        this.sendername = sendername;
    }

    
    public Boolean getFlag() {
        return flag;
    }

    public void setFlag(Boolean flag) {
        this.flag = flag;
    }

    public Intern getIntern() {
        return intern;
    }

    public void setIntern(Intern intern) {
        this.intern = intern;
    }

    public Contractor getContractor() {
        return contractor;
    }

    public void setContractor(Contractor contractor) {
        this.contractor = contractor;
    }


    
    
    public int getApplicationID() {
        return applicationID;
    }

    public void setApplicationID(int applicationID) {
        this.applicationID = applicationID;
    }

    public Job getJob() {
        return job;
    }

    public void setJob(Job job) {
        this.job = job;
    }

    public Applicant getApplicant() {
        return applicant;
    }

    public void setApplicant(Applicant applicant) {
        this.applicant = applicant;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return status ;
    }
    
    
}


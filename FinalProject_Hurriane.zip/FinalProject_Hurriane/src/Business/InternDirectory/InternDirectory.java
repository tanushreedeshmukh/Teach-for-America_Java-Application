/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.InternDirectory;

import java.util.ArrayList;

/**
 *
 * @author Vrushali
 */
public class InternDirectory {
    
     private ArrayList<Intern> internList;

    public InternDirectory() {
        this.internList = new ArrayList<>();
    }

    public ArrayList<Intern> getInternList() {
        return internList;
    }

    public void setInternList(ArrayList<Intern> internList) {
        this.internList = internList;
    }

   
    
   public Intern addPerson(String name,Boolean flag, String hired)
    {
        Intern np= new Intern();
        np.setName(name);
        np.setFlag(flag);
        np.setPersonID(np.getPersonID());
        np.setHired(hired);
        internList.add(np);
        return np;
    }  
    
    public void removeperson(Intern intern){
        internList.remove(intern);
            
    }
    
}

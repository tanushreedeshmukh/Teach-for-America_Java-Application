/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Application;

import Business.Applicant.Applicant;
import Business.ContractorPersonDirectory.Contractor;
import Business.InternDirectory.Intern;
import Business.Jobs.Job;

/**
 *
 * @author Tanushree
 */
public class Application {
    public Job job;
    private Applicant applicant;
    private Contractor contractor;
    private Intern intern;
    private static int count = 0;
    private int applicationID;

  

    public Application() {
        this.job = job;
        count++;
        applicationID = count;
        this.applicant = applicant;

    }

    public Job getJob() {
        return job;
    }

    public void setJob(Job job) {
        this.job = job;
    }

    public Applicant getApplicant() {
        return applicant;
    }

    public void setApplicant(Applicant applicant) {
        this.applicant = applicant;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Application.count = count;
    }

    public int getApplicationID() {
        return applicationID;
    }

      public void setApplicationID(int applicationID) {
        this.applicationID = applicationID;
    }
    public Contractor getContractor() {
        return contractor;
    }

    public void setContractor(Contractor contractor) {
        this.contractor = contractor;
    }

   

    public Intern getIntern() {
        return intern;
    }

    public void setIntern(Intern intern) {
        this.intern = intern;
    }

    
    
}

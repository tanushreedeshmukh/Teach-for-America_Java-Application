/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userinterface.HR;

import Business.ApplicationWorkQueue.ApplicantWorkRequest;
import Business.ApplicationWorkQueue.HRWorkRequest;
import Business.ApplicationWorkQueue.WorkRequest;
import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Network.Network;
import Business.Organization.Organization;
import Business.Organization.OrganizationDirectory;
import Business.Organization.TFAOrganization;
import Business.Role.Role;
import Business.Role.SupervisorRole;
import Business.UserAccount.UserAccount;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Tanushree
 */
public class ContractorWorkArea extends javax.swing.JPanel {

    /**
     * Creates new form ContractorWorkArea
     */
     JPanel userProcessContainer;
    EcoSystem business;
    TFAOrganization tfaorganization;
    OrganizationDirectory organizationDirectory;
    UserAccount account;

    public ContractorWorkArea(JPanel userProcessContainer, EcoSystem business, TFAOrganization tfaorganization, OrganizationDirectory organizationDirectory, UserAccount account) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.business = business;
        this.tfaorganization = tfaorganization;
        this.account = account;
        this.organizationDirectory = organizationDirectory;
       // populateJobTable();
        populateNGOTable();
         populateSupTable();
        populateHRWorkRequestTable();
    }
     public void populateSupTable() {
        DefaultTableModel model = (DefaultTableModel) tblSUP.getModel();

        model.setRowCount(0);
        for (Network network : business.getNetworkList()) {
            for (Enterprise enterprise : network.getEnterpriseDirectory().getEnterpriseList()) {
                for (Organization org : enterprise.getOrganizationDirectory().getOrganizationList()) {
                    if (org instanceof TFAOrganization) {
                        for (UserAccount useraccount : org.getUserAccountDirectory().getUserAccountList()) {
                            if (useraccount.getRole() instanceof SupervisorRole) {
                                Object[] row = new Object[2];
                                row[0] = useraccount.getRole();
                                row[1] = useraccount;
                                model.addRow(row);
                            }
                        }
                    }
                }
            }
        }
    }

    public void populateNGOTable() {
        DefaultTableModel model = (DefaultTableModel) tblNGO.getModel();

        model.setRowCount(0);
        for (Network network : business.getNetworkList()) {
            for (Enterprise enterprise : network.getEnterpriseDirectory().getEnterpriseList()) {
                for (Organization org : enterprise.getOrganizationDirectory().getOrganizationList()) {
                    for (WorkRequest work : org.getWorkQueue().getWorkRequestList()) {
                        if (work instanceof ApplicantWorkRequest) {
                            if (((ApplicantWorkRequest) work).getIntern()!= null) {
                                Object[] row = new Object[4];
                                row[0] = work;
                                row[1] = ((ApplicantWorkRequest) work).getApplicationID();
                                row[2] = ((ApplicantWorkRequest) work).getJob().getJobPosition();
                                row[3] = ((ApplicantWorkRequest) work).getSendername();
                                model.addRow(row);
                            }
                        }
                    }
                }
            }
        }
    }

public void populateHRWorkRequestTable() {
        DefaultTableModel model = (DefaultTableModel) tblHR.getModel();
        model.setRowCount(0);
        outer:
        for (UserAccount useraccount : tfaorganization.getUserAccountDirectory().getUserAccountList()) {
            if (useraccount.getRole() instanceof SupervisorRole) {
                for (WorkRequest work : useraccount.getWorkQueue().getWorkRequestList()) {

                    if (work instanceof HRWorkRequest) {
                        Object[] row = new Object[4];
                        row[0] = work;
                        row[1] = ((HRWorkRequest) work).getJob();
                        row[2] = ((HRWorkRequest) work).getName();
                        row[3] = ((HRWorkRequest) work).getSender();
                        model.addRow(row);

                    }

                }
//              
            }
        }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblSUP = new javax.swing.JTable();
        jScrollPane7 = new javax.swing.JScrollPane();
        tblNGO = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        tblHR = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 204, 153));

        tblSUP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Role", "Supervisor Name"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblSUP);

        tblNGO.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Application Status", "Application ID", "Job Position", "Applicant Name"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane7.setViewportView(tblNGO);

        jButton1.setText("Assign to Supervisor");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        tblHR.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Application Status", "Job Position", "Applicant Name", "Supervisor Name"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane5.setViewportView(tblHR);

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Application Status -- >>");

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("Supervisor");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("HR Work Area(Intern)");

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Interns");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(54, 54, 54)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jButton1))
                                .addGap(88, 88, 88))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 530, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(268, 268, 268)
                        .addComponent(jLabel2)))
                .addContainerGap(212, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(71, 71, 71)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addContainerGap(108, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       
        int seletedNgo = tblNGO.getSelectedRow();
       
        int seletedSup = tblSUP.getSelectedRow();
        Role role = (Role) (SupervisorRole) tblSUP.getValueAt(seletedSup, 0);

        if (seletedNgo >= 0 && seletedSup >= 0) {

            outer:
            for (Network network : business.getNetworkList()) {
                for (Enterprise enterprise : network.getEnterpriseDirectory().getEnterpriseList()) {
                    for (Organization org : enterprise.getOrganizationDirectory().getOrganizationList()) {
                        for (UserAccount useraccount : org.getUserAccountDirectory().getUserAccountList()) {
                            if (useraccount.getRole() instanceof SupervisorRole && useraccount.getRole().equals(role)) {

                                HRWorkRequest hRWorkRequest = new HRWorkRequest();
                                hRWorkRequest.setJob(((ApplicantWorkRequest) tblNGO.getValueAt(seletedNgo, 0)).getJob());
                                hRWorkRequest.setStatus("Interview Scheduled");
                                hRWorkRequest.setSender((UserAccount) tblSUP.getValueAt(seletedSup, 1));
                                hRWorkRequest.setApplicationID(((ApplicantWorkRequest) tblNGO.getValueAt(seletedNgo, 0)).getApplicationID());
                                hRWorkRequest.setName(((ApplicantWorkRequest) tblNGO.getValueAt(seletedNgo, 0)).getSendername());
                                org.getWorkQueue().getWorkRequestList().add(hRWorkRequest);
                                useraccount.getWorkQueue().getWorkRequestList().add(hRWorkRequest);
                                business.getWorkQueue().getWorkRequestList().add(hRWorkRequest);
                              
                                populateHRWorkRequestTable();
                                break outer;
                            }
                        }
                    }
                }
            }
            JOptionPane.showMessageDialog(jButton1, "Assigned Succesfully");
        } 
        else
            JOptionPane.showMessageDialog(jButton1, "Please select proper values");
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTable tblHR;
    private javax.swing.JTable tblNGO;
    private javax.swing.JTable tblSUP;
    // End of variables declaration//GEN-END:variables
}

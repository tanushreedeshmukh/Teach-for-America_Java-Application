/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userinterface.HR;

import Business.ApplicationWorkQueue.ApplicantWorkRequest;
import Business.ApplicationWorkQueue.HRWorkRequest;
import Business.ApplicationWorkQueue.WorkRequest;
import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Network.Network;
import Business.Organization.Organization;
import Business.Organization.TFAOrganization;
import Business.Role.Role;
import Business.Role.TrainingOfficerRole;
import Business.UserAccount.UserAccount;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import Business.Applicant.Applicant;
import java.awt.CardLayout;
import javax.mail.MessagingException;
import userinterface.Main.ReviewPage;

/**
 *
 * @author Tanushree
 */
 
public class PermanentWorkArea extends javax.swing.JPanel {

    /**
     * Creates new form PermanentWorkArea
     */
    JPanel userprocesscontainer;
    EcoSystem business;
    TFAOrganization tfaOrganization;
    UserAccount userAccount;
    private static String emailMsgTxt = "";
   private static String emailSubjectTxt = "";
   private static String emailFromAddress = "";
    public PermanentWorkArea(JPanel userProcessContainer, EcoSystem business, TFAOrganization tfaOrganization, UserAccount account) {
        initComponents();
         this.userprocesscontainer = userProcessContainer;
        this.business = business;
        this.tfaOrganization = tfaOrganization;
        this.userAccount = userAccount;
        populateWorkQueueTable();
        populateTOTable();
        populateHRWorkRequestTable();
      //  populateSortApplicantsTable();
    }

   /* public void populateSortApplicantsTable(){
         DefaultTableModel model = (DefaultTableModel) sortApplicantsTbl.getModel();  
         model.setRowCount(0);
   for (Network network : business.getNetworkList()) {
                for (Enterprise enterprise : network.getEnterpriseDirectory().getEnterpriseList()) {
                    for (Organization org : enterprise.getOrganizationDirectory().getOrganizationList()) {
                        for (Applicant applicant : org.getApplicantDirectory().getApplicantlist()) {
                           Object[] row = new Object[4];
                row[0] = applicant; 
                row[1]=applicant.getFirstName();
                row[2]=applicant.getQualification();
                row[3]=applicant.getEducation();
                        }
                        
    }
    
    
           }  
   }
    }*/
   public void populateWorkQueueTable() {
        DefaultTableModel model = (DefaultTableModel) requestTable.getModel();

        model.setRowCount(0);

        for (WorkRequest work : tfaOrganization.getWorkQueue().getWorkRequestList()) {
            if (work instanceof ApplicantWorkRequest) {
                Object[] row = new Object[5];
                row[0] = work;
                row[1] = ((ApplicantWorkRequest) work).getApplicationID();
                row[2] = ((ApplicantWorkRequest) work).getJob().getJobPosition();
                row[3] = ((ApplicantWorkRequest) work).getSender();
                //row[4]=((ApplicantWorkRequest)work).getApplicant().getFirstName();
                //row[4]=((ApplicantWorkRequest)work).getApplicant().getQualification();
                model.addRow(row);
            }
        }
    }

    public void populateTOTable() {
        DefaultTableModel model = (DefaultTableModel) tblCto.getModel();

        model.setRowCount(0);

        for (UserAccount useraccount : tfaOrganization.getUserAccountDirectory().getUserAccountList()) {
            if (useraccount.getRole() instanceof TrainingOfficerRole) {
                Object[] row = new Object[2];
                row[0] = useraccount.getRole();
                row[1] = useraccount;
                model.addRow(row);
            }
        }
    }

    public void populateHRWorkRequestTable() {
        DefaultTableModel model = (DefaultTableModel) hrrequestTable.getModel();
        model.setRowCount(0);
        outer:
        for (UserAccount useraccount : tfaOrganization.getUserAccountDirectory().getUserAccountList()) {
            if (useraccount.getRole() instanceof TrainingOfficerRole) {
                for (WorkRequest work : useraccount.getWorkQueue().getWorkRequestList()) {

                    if (work instanceof HRWorkRequest) {
                        Object[] row = new Object[4];
                        row[0] = work;
                        row[1] = ((HRWorkRequest) work).getApplicationID();
                        row[2] = ((HRWorkRequest) work).getJob().getJobPosition();
                        row[3] = ((HRWorkRequest) work).getAccount();
                       
        
                        model.addRow(row);

                    }

                }
//              
            }
        }

    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        tblCto = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnAssign = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        hrrequestTable = new javax.swing.JTable();
        btnDisplay = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        requestTable = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        backBtn = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 204, 153));

        tblCto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Role", "CTO Name"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tblCto);

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("Applications");

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Training Officer");

        btnAssign.setText("Assign for Interview");
        btnAssign.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAssignActionPerformed(evt);
            }
        });

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("HR Work Queue -->>");

        hrrequestTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Application Status", "Application ID", "Job Position", "Applicant Name"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(hrrequestTable);

        btnDisplay.setText("Dispay result to Applicant");
        btnDisplay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDisplayActionPerformed(evt);
            }
        });

        requestTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Application Status", "Application ID", "Job Position", "Applicant Name"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(requestTable);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("HR Work Area(Permanent)");

        backBtn.setText("<< Back");
        backBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnAssign))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnDisplay)
                                .addGap(26, 26, 26))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 381, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)
                            .addComponent(backBtn))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 411, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 296, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(294, 294, 294))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(backBtn)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(55, 55, 55)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(18, 18, 18)
                                .addComponent(btnAssign)
                                .addGap(18, 18, 18)
                                .addComponent(btnDisplay))
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(209, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnAssignActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAssignActionPerformed

        int selectedApprow = requestTable.getSelectedRow();
        int selectedCtorow = tblCto.getSelectedRow();
        Role role = (Role) (TrainingOfficerRole) tblCto.getValueAt(selectedCtorow, 0);
        if (selectedApprow>=0 && selectedCtorow>=0) {
            outer:
            for (Network network : business.getNetworkList()) {
                for (Enterprise enterprise : network.getEnterpriseDirectory().getEnterpriseList()) {
                    for (Organization org : enterprise.getOrganizationDirectory().getOrganizationList()) {
                        for (UserAccount useraccount : org.getUserAccountDirectory().getUserAccountList()) {
                            if (useraccount.getRole() instanceof TrainingOfficerRole && useraccount.getRole().equals(role)) {

                                HRWorkRequest hRWorkRequest = new HRWorkRequest();
                                hRWorkRequest.setApplicant(((ApplicantWorkRequest) requestTable.getValueAt(selectedApprow, 0)).getApplicant());
                                hRWorkRequest.setJob(((ApplicantWorkRequest) requestTable.getValueAt(selectedApprow, 0)).getJob());
                                hRWorkRequest.setApplicationID(((ApplicantWorkRequest) requestTable.getValueAt(selectedApprow, 0)).getApplicationID());
                                //hRWorkRequest.setRole(role);
                                hRWorkRequest.setStatus("Interview Scheduled");
                                hRWorkRequest.setAccount(((ApplicantWorkRequest) requestTable.getValueAt(selectedApprow, 0)).getSender());
                                tfaOrganization.getWorkQueue().getWorkRequestList().add(hRWorkRequest);
                                useraccount.getWorkQueue().getWorkRequestList().add(hRWorkRequest);
                                business.getWorkQueue().getWorkRequestList().add(hRWorkRequest);
                                populateHRWorkRequestTable();
                                 populateWorkQueueTable();
                                break outer;
                            }
                        }
                    }
                }
            }
            JOptionPane.showMessageDialog(btnAssign, "Assigned Succesfuly");
        }
        else
        JOptionPane.showMessageDialog(btnAssign, "Please select valid application and valid Cto");
    }//GEN-LAST:event_btnAssignActionPerformed

    private void btnDisplayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDisplayActionPerformed
      int selectedDisplay = hrrequestTable.getSelectedRow();
        if(selectedDisplay>=0)
        {
            HRWorkRequest hrreRequest = (HRWorkRequest) hrrequestTable.getValueAt(selectedDisplay, 0);
            outer:
            for (UserAccount useraccount : tfaOrganization.getUserAccountDirectory().getUserAccountList()) {
                for (WorkRequest work : tfaOrganization.getWorkQueue().getWorkRequestList()) {
                    if (work instanceof ApplicantWorkRequest && hrreRequest.getAccount()== ((ApplicantWorkRequest) work).getSender() && hrreRequest.getJob().equals(((ApplicantWorkRequest) work).getJob())) {
                        if (hrreRequest.getStatus().equals("Rejected")) {
                            work.setStatus("Rejected");
                            
                emailMsgTxt = "Rejected!";
                emailSubjectTxt = "Sorry!!You are rejected";
                emailFromAddress = SendMailUsingAuthentication.SMTP_AUTH_USER;  

                SendMailUsingAuthentication smtpMailSender = new SendMailUsingAuthentication();
                    try {
                        smtpMailSender.postMail("deshmukh.tanushree@gmail.com", emailSubjectTxt, emailMsgTxt, emailFromAddress);
                       
                        JOptionPane.showMessageDialog(this, "Mail ready to send");
                        
                        
                    }catch (MessagingException ex) {
                        System.out.println("EXCEPTION : "+ ex);
                        JOptionPane.showMessageDialog(this, "Request cannot be processed now",
                                    "wait!!!",JOptionPane.WARNING_MESSAGE);}
                            

                        } else {
                            work.setStatus("Selected");
                emailMsgTxt = "Congratulations!!You are Selected";
                emailSubjectTxt = "Application Result";
                emailFromAddress = SendMailUsingAuthentication.SMTP_AUTH_USER;  

                SendMailUsingAuthentication smtpMailSender = new SendMailUsingAuthentication();
                    try {
                        smtpMailSender.postMail(work.getEmail(), emailSubjectTxt, emailMsgTxt, emailFromAddress);
                       
                        JOptionPane.showMessageDialog(this, "Mail ready to send");
                        
                        
                    }catch (MessagingException ex) {
                        System.out.println("EXCEPTION : "+ ex);
                        JOptionPane.showMessageDialog(this, "Request cannot be processed now",
                                    "wait!!!",JOptionPane.WARNING_MESSAGE);}
                            
                            }
                        
                        break outer;

                    }
                }
            }
            populateWorkQueueTable();
            JOptionPane.showMessageDialog(btnDisplay, "Sent succesfully");
        }
        else
        JOptionPane.showMessageDialog(btnDisplay, "Cant send this message,Please select a data from the table");
        
        
        
       /* emailMsgTxt = "Hi,Hello super cello";
                emailSubjectTxt = "RAM RAM";
                emailFromAddress = SendMailUsingAuthentication.SMTP_AUTH_USER;  

                SendMailUsingAuthentication smtpMailSender = new SendMailUsingAuthentication();
                    try {
                        smtpMailSender.postMail("deshmukh.tanushree@gmail.com", emailSubjectTxt, emailMsgTxt, emailFromAddress);
                       
                        JOptionPane.showMessageDialog(this, "Your password has been changed, Please check your mail.");
                        
                        
                    }catch (MessagingException ex) {
                        System.out.println("EXCEPTION : "+ ex);
                        JOptionPane.showMessageDialog(this, "Request cannot be processed now, Please try after sometime",
                                    "Decentralised Health Care System",JOptionPane.WARNING_MESSAGE);}*/
    }//GEN-LAST:event_btnDisplayActionPerformed

    private void backBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBtnActionPerformed
        // TODO add your handling code here:
         userprocesscontainer.remove(this);
        CardLayout layout = (CardLayout) userprocesscontainer.getLayout();
        layout.previous(userprocesscontainer);
       
    }//GEN-LAST:event_backBtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backBtn;
    private javax.swing.JButton btnAssign;
    private javax.swing.JButton btnDisplay;
    private javax.swing.JTable hrrequestTable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable requestTable;
    private javax.swing.JTable tblCto;
    // End of variables declaration//GEN-END:variables
}
